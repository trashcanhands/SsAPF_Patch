using ModShardLauncher;
using ModShardLauncher.Mods;

namespace AutoPathfinderPatch
{
    public class AutoPathfinderPatch : Mod
    {
        public override string Author => "Patch for AutoPathfinder";
        public override string Name => "AutoPathfinder Marker Fix";
        public override string Description => "Fixes execute_pathfinder to work with new marker system. Load AFTER original AutoPathfinder mod.";
        public override string Version => "1.0.0.0";

        public override void PatchMod()
        {
            Msl.LoadGML("gml_Object_o_player_KeyPress_114")
                .MatchAll()
                .ReplaceBy(ModFiles.GetCode("execute_pathfinder_announce.gml"))
                .Save();
        }
    }
}
