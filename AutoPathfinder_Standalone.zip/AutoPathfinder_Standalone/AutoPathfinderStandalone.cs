using ModShardLauncher;
using ModShardLauncher.Mods;
using UndertaleModLib.Models;

namespace AutoPathfinderStandalone
{
    public class AutoPathfinderStandalone : Mod
    {
        public override string Author => "Fixed for current Stoneshard";
        public override string Name => "AutoPathfinder Standalone";
        public override string Description => "Auto-pathfinding to flag markers. Press configured hotkey (default F3).";
        public override string Version => "2.0.0.0";
        
        // ========================================
        // CONFIGURE YOUR HOTKEY HERE!
        // ========================================
        // Change this number to use a different key
        // Common keys:
        //   F1 = 112, F2 = 113, F3 = 114, F4 = 115, F5 = 116
        //   F6 = 117, F7 = 118, F8 = 119, F9 = 120, F10 = 121
        //   P = 80, O = 79, I = 73, U = 85
        //   Home = 36, End = 35, Insert = 45, Delete = 46
        private const uint HOTKEY = 114;  // F3 by default
        // ========================================

        public override void PatchMod()
        {
            // MSL-Enhanced compatible: Replace F3 with single self-contained file
            // All helper functions are inline - no AddFunction needed!
            Msl.LoadGML("gml_Object_o_player_KeyPress_" + HOTKEY)
                .MatchAll()
                .ReplaceBy(ModFiles.GetCode("execute_pathfinder_inline.gml"))
                .Save();
            
            // Add Step event checker at the START of Step_0
            // InsertAbove to avoid breaking code structure at the end
            Msl.LoadGML("gml_Object_o_player_Step_0")
                .MatchAll()
                .InsertAbove(ModFiles.GetCode("step_handler.gml"))
                .Save();
        }
    }
}
